module.exports = {
    name: 'gresume',
    description: 'Resume a paused giveaway.',
    category: 'giveaway',
    usage: 'gresume <giveaway_message_id>',

    async run(client, message, args) {
        // Check if the message author has the necessary permission
        if (!message.member.permissions.has('MANAGE_GUILD')) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setDescription('<:cross:1351794637756694569> You need `Manage Server` permission to resume a giveaway.')
                        .setColor('RED')
                ]
            });
        }

        const giveawayMessageId = args[0];
        if (!giveawayMessageId) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setDescription('<:cross:1351794637756694569> Please specify a valid giveaway message ID.')
                        .setColor('RED')
                ]
            });
        }

        const giveaway = giveaways.get(giveawayMessageId);
        if (!giveaway) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setDescription('<:cross:1351794637756694569> No giveaway found with that message ID.')
                        .setColor('RED')
                ]
            });
        }

        if (!giveaway.paused) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setDescription('<:cross:1351794637756694569> This giveaway is not paused.')
                        .setColor('RED')
                ]
            });
        }

        giveaway.paused = false;

        // Reactivate the giveaway by editing the message again
        const giveawayMessage = await message.channel.messages.fetch(giveawayMessageId);
        await giveawayMessage.edit({
            embeds: [
                new MessageEmbed()
                    .setTitle('🎉 Giveaway!🎉')
                    .setDescription(`**<a:black_dot:1354322177318453331> Prize:** ${giveaway.prize}
**<a:black_dot:1354322177318453331> Duration:** ${giveaway.duration}
**<a:black_dot:1354322177318453331> Hosted By:** ${giveaway.host}
**<a:black_dot:1354322177318453331> Status:** **Active**`)
                    .setColor('BLACK')
                    .setFooter(' React with 🎉 to enter!')
            ]
        });

        message.reply({
            embeds: [
                new MessageEmbed()
                    .setDescription('<:cross:1351794637756694569> The giveaway has been resumed. You can now react to participate!')
                    .setColor('GREEN')
            ]
        });
    },
};

const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');
const ms = require('ms'); // For parsing duration strings

module.exports = {
    name: 'gstart',
    description: 'Start a giveaway.',
    category: 'giveaway',
    usage: 'gstart <time> <winner_count> <prize>',

    async run(client, message, args) {
        // Check permissions
        if (!message.member.permissions.has('MANAGE_GUILD')) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setDescription('<:cross:1351794637756694569> You need `Manage Server` permission to start a giveaway.')
                        .setColor('RED')
                ]
            });
        }

        // Parse arguments
        const time = args[0];
        const winnerCount = parseInt(args[1]);
        const prize = args.slice(2).join(' ');

        if (!time || !ms(time)) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setDescription('<:cross:1351794637756694569> Please specify a valid duration (e.g., `10m`, `1h`, `1d`).')
                        .setColor('RED')
                ]
            });
        }

        if (!winnerCount || isNaN(winnerCount) || winnerCount <= 0) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setDescription('<:cross:1351794637756694569> Please specify a valid number of winners.')
                        .setColor('RED')
                ]
            });
        }

        if (!prize) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setDescription('<:cross:1351794637756694569> Please specify the prize for the giveaway.')
                        .setColor('RED')
                ]
            });
        }

        // Create giveaway embed
        const embed = new MessageEmbed()
            .setTitle('🎉 Giveaway!🎉')
            .setDescription(`**<a:black_dot:1354322177318453331> Prize:** ${prize}
**<a:black_dot:1354322177318453331> Duration:** ${time}
**<a:black_dot:1354322177318453331> Hosted By:** ${message.author}`)
            .setColor('BLACK')
            .setTimestamp(Date.now() + ms(time))
            .setFooter(' React with 🎉 to enter!');

        // Send the giveaway message
        const giveawayMessage = await message.channel.send({
            embeds: [embed],
        });

        // React to the message with 🎉
        await giveawayMessage.react('🎉');

        // Wait for the giveaway to end
        setTimeout(async () => {
            const reaction = giveawayMessage.reactions.cache.get('🎉');
            if (!reaction) return;

            const users = await reaction.users.fetch();
            const participants = users.filter((u) => !u.bot).random(winnerCount);

            if (!participants.length) {
                return message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setDescription('<:cross:1351794637756694569> No valid participants, giveaway canceled.')
                            .setColor('RED')
                    ]
                });
            }

            const winners = participants.map((u) => `<@${u.id}>`).join(', ');
            message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setTitle('🎉 Giveaway Ended!🎉')
                        .setDescription(`**<a:black_dot:1354322177318453331> Prize:** ${prize}
**<a:black_dot:1354322177318453331> Winners:** ${winners}
**<a:black_dot:1354322177318453331> Hosted By:** ${message.author}`)
                        .setColor('BLACK')
                ]
            });
        }, ms(time));
    },
};
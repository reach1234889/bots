const { MessageEmbed, Permissions, MessageActionRow, MessageButton } = require('discord.js');

module.exports = {
    name: 'roleall',
    aliases: ['giveroleall'],
    category: 'mod',
    premium: false,

    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);

        if (!message.member.permissions.has('MANAGE_ROLES'))
            return message.channel.send({ embeds: [embed.setDescription("You need `Manage Roles` permission to use this command.")] });

        if (!message.guild.me.permissions.has('MANAGE_ROLES'))
            return message.channel.send({ embeds: [embed.setDescription("I need `Manage Roles` permission to do this.")] });

        const roleName = args.join(' ');
        if (!roleName)
            return message.channel.send({ embeds: [embed.setDescription("Please specify a role name or mention.")] });

        const role = message.guild.roles.cache.find(r => r.name.toLowerCase() === roleName.toLowerCase()) ||
                     message.mentions.roles.first() ||
                     message.guild.roles.cache.get(roleName.replace(/[<@&>]/g, ''));

        if (!role)
            return message.channel.send({ embeds: [embed.setDescription("Couldn't find the role you specified.")] });

        const dangerousPermissions = [
            "ADMINISTRATOR", "MANAGE_GUILD", "MANAGE_CHANNELS", "MANAGE_ROLES",
            "KICK_MEMBERS", "BAN_MEMBERS", "MENTION_EVERYONE", "MANAGE_WEBHOOKS",
            "MANAGE_EVENTS", "MODERATE_MEMBERS", "MANAGE_EMOJIS_AND_STICKERS"
        ];
        const rolePerms = new Permissions(role.permissions.bitfield).toArray();

        if (rolePerms.some(p => dangerousPermissions.includes(p)))
            return message.channel.send({ embeds: [embed.setDescription(`Cannot assign role with dangerous permissions: ${rolePerms.filter(p => dangerousPermissions.includes(p)).map(p => `\`${p}\``).join(', ')}`)] });

        if (role.position >= message.guild.me.roles.highest.position)
            return message.channel.send({ embeds: [embed.setDescription("I can't assign a role higher or equal to my highest role.")] });

        let members = await message.guild.members.fetch();
        members = members.filter(member => !member.user.bot && !member.roles.cache.has(role.id));

        if (!members.size)
            return message.channel.send({ embeds: [embed.setDescription("Everyone already has this role!")] });

        // Create buttons for confirmation
        const row = new MessageActionRow().addComponents(
            new MessageButton()
                .setCustomId('confirm')
                .setLabel('OK')
                .setStyle('SUCCESS'),
            new MessageButton()
                .setCustomId('cancel')
                .setLabel('Cancel')
                .setStyle('DANGER')
        );

        const confirmationEmbed = new MessageEmbed()
            .setColor(client.color)
            .setDescription(`Are you sure you want to give **${role.name}** to **${members.size}** members?`);

        const confirmationMessage = await message.channel.send({ embeds: [confirmationEmbed], components: [row] });

        const filter = (interaction) => interaction.user.id === message.author.id;
        const collector = confirmationMessage.createMessageComponentCollector({ filter, time: 15000, max: 1 });

        collector.on('collect', async (interaction) => {
            if (interaction.customId === 'confirm') {
                await interaction.update({ components: [] });

                let success = 0;
                let failed = 0;
                const delay = 1500; // 1.5 seconds per member

                await message.channel.send({ embeds: [embed.setDescription(`Starting to give **${role.name}** to **${members.size}** members... This will take some time.`)] });

                for (const member of members.values()) {
                    try {
                        await member.roles.add(role);
                        success++;
                    } catch (e) {
                        failed++;
                    }
                    await new Promise(res => setTimeout(res, delay));
                }

                return message.channel.send({
                    embeds: [
                        embed.setTitle('Role Assignment Completed')
                            .setDescription(`Finished assigning **${role.name}**.`)
                            .addField('Successful', `${success}`, true)
                            .addField('Failed', `${failed}`, true)
                    ]
                });
            } else if (interaction.customId === 'cancel') {
                await interaction.update({ components: [] });
                return message.channel.send({ embeds: [embed.setDescription('Role assignment has been cancelled.')] });
            }
        });

        collector.on('end', async (collected) => {
            if (!collected.size) {
                await confirmationMessage.edit({ components: [] });
                return message.channel.send({ embeds: [embed.setDescription('Confirmation timed out. Command cancelled.')] });
            }
        });
    }
};